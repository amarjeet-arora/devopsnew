package com.jpa.springdatajpahibernateexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaHibernateExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaHibernateExampleApplication.class, args);
	}
}
